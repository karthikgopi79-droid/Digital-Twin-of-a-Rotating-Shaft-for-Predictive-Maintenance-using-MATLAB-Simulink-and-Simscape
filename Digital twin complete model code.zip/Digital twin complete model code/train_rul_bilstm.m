function train_rul_bilstm()
%TRAIN_RUL_BILSTM
%  Train a BiLSTM-based RUL predictor on 30-day sequences (12 features).
%
%  Uses:
%    data/sequences/degradation_lstm_data.mat  (XSeq, YSeq, winLenDays)
%
%  Saves:
%    data/models/rul_bilstm_model.mat with:
%       rulBiLSTM   : trained network
%       featMin     : [12x1] feature minima for 0-1 scaling
%       featMax     : [12x1] feature maxima

    % --- Locate project root and load data ---
    scriptPath = mfilename('fullpath');
    [scriptDir, ~, ~] = fileparts(scriptPath);
    projectRoot = fileparts(fileparts(scriptDir));  % .../03_rul_predictor -> ml_pipelines -> root

    dataFile = fullfile(projectRoot, 'data', 'sequences', 'degradation_lstm_data.mat');
    if ~isfile(dataFile)
        error('RUL data not found: %s. Make sure create_degradation_sequences_from_real_data was run.', dataFile);
    end

    S = load(dataFile, 'XSeq', 'YSeq', 'winLenDays');
    XSeq = S.XSeq;
    YSeq = S.YSeq;
    seqLen = S.winLenDays;

    numSamples  = numel(XSeq);
    numFeatures = size(XSeq{1}, 1);

    fprintf('Loaded %d sequences (features=%d, seqLen=%d)\n', numSamples, numFeatures, seqLen);

    % --- Feature normalization to [0,1] per feature ---
    % Stack all features to compute min/max
    allFeat = [];
    for i = 1:numSamples
        allFeat = [allFeat, XSeq{i}]; %#ok<AGROW>  % [12 x 30] concatenated
    end
    featMin = min(allFeat, [], 2);                 % [12 x 1]
    featMax = max(allFeat, [], 2);
    range   = featMax - featMin + 1e-8;           % avoid division by zero

    for i = 1:numSamples
        XSeq{i} = (XSeq{i} - featMin) ./ range;   % each [12 x 30] scaled to 0-1
    end

    % --- Train/val/test split ---
    % Spec says: 1000+ lifecycles → we have 2461 sequences. Use 60/20/20.
    rng(0);
    idx = randperm(numSamples);

    nTrain = round(0.6 * numSamples);
    nVal   = round(0.2 * numSamples);
    nTest  = numSamples - nTrain - nVal;

    trainIdx = idx(1:nTrain);
    valIdx   = idx(nTrain+1 : nTrain+nVal);
    testIdx  = idx(nTrain+nVal+1 : end);

    XTrain = XSeq(trainIdx);
    YTrain = YSeq(trainIdx);
    XVal   = XSeq(valIdx);
    YVal   = YSeq(valIdx);
    XTest  = XSeq(testIdx);
    YTest  = YSeq(testIdx);

    fprintf('Split: %d train, %d val, %d test sequences\n', numel(XTrain), numel(XVal), numel(XTest));

    % --- Define BiLSTM architecture (approximate your spec) ---
    layers = [
        sequenceInputLayer(numFeatures, 'Name','input')

        bilstmLayer(64, 'OutputMode','last', 'Name','bilstm')  % 64 each direction, 128 concat
        dropoutLayer(0.3, 'Name','drop_bi')

        fullyConnectedLayer(32, 'Name','fc1')
        reluLayer('Name','relu1')
        dropoutLayer(0.3, 'Name','drop_fc')

        fullyConnectedLayer(1, 'Name','fc_out')
        regressionLayer('Name','regressionoutput')
    ];

    % --- Training options ---
    % AdamW not directly available; approximate with Adam + L2 regularization.
    initialLR = 1e-3;

    options = trainingOptions('adam', ...
        'InitialLearnRate', initialLR, ...
        'L2Regularization', 1e-3, ...    % weight decay approximation
        'MaxEpochs', 150, ...
        'MiniBatchSize', 16, ...
        'Shuffle', 'every-epoch', ...
        'ValidationData', {XVal, YVal}, ...
        'ValidationFrequency', 50, ...
        'ValidationPatience', 20, ...    % early stopping
        'ExecutionEnvironment', 'auto', ...
        'GradientThreshold', 1, ...      % gradient clipping
        'Plots', 'training-progress', ...
        'Verbose', false);

    fprintf('Training BiLSTM RUL predictor...\n');
    rulBiLSTM = trainNetwork(XTrain, YTrain, layers, options);

    % --- Evaluate on test set ---
    YPred = predict(rulBiLSTM, XTest, 'MiniBatchSize', 16);

    mae  = mean(abs(YPred - YTest));
    rmse = sqrt(mean((YPred - YTest).^2));
    R2   = 1 - sum((YPred - YTest).^2) / sum((YTest - mean(YTest)).^2);

    within5  = mean(abs(YPred - YTest) <=  5) * 100;
    within10 = mean(abs(YPred - YTest) <= 10) * 100;
    within15 = mean(abs(YPred - YTest) <= 15) * 100;

    mape = mean(abs((YPred - YTest) ./ max(YTest, 1e-6))) * 100;  % avoid div by 0

    fprintf('\nTest performance (BiLSTM RUL predictor):\n');
    fprintf('  MAE  = %.2f days\n', mae);
    fprintf('  RMSE = %.2f days\n', rmse);
    fprintf('  R^2  = %.3f\n', R2);
    fprintf('  MAPE = %.1f %%\n', mape);
    fprintf('  %% within ±5 days  = %.1f %%\n', within5);
    fprintf('  %% within ±10 days = %.1f %%\n', within10);
    fprintf('  %% within ±15 days = %.1f %%\n', within15);

    % --- Save model and normalization params ---
    outDir = fullfile(projectRoot, 'data', 'models');
    if ~isfolder(outDir), mkdir(outDir); end

    outFile = fullfile(outDir, 'rul_bilstm_model.mat');
    save(outFile, 'rulBiLSTM', 'featMin', 'featMax');

    fprintf('\nSaved BiLSTM RUL model to %s\n', outFile);
end