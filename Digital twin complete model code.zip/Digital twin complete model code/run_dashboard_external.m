function run_dashboard_external()
% Launch the existing motor_dashboard.mlapp UI and wire it externally.

projectRoot = fileparts(fileparts(mfilename("fullpath")));
addpath(genpath(projectRoot));

app = motor_dashboard; % opens your existing mlapp UI

% Configure spinner as Asset selector
app.SpinnerLabel.Text = "Asset";
app.Spinner.Limits = [1 80];
app.Spinner.Step   = 1;
if app.Spinner.Value < 1
    app.Spinner.Value = 1;
end

% Runtime state stored in UIFigure.UserData
ud = struct();
ud.projectRoot = projectRoot;
ud.hasState    = false;
ud.state       = [];
ud.tmr         = [];
app.UIFigure.UserData = ud;

% Attach callbacks
app.StartButton.ButtonPushedFcn = @(~,~) onStart(app);
app.PuaseButton.ButtonPushedFcn = @(~,~) onPause(app);
app.StopButton.ButtonPushedFcn  = @(~,~) onStop(app);
app.Spinner.ValueChangedFcn     = @(~,~) onAssetChanged(app);

% Initial UI text / labels
app.Label.Text  = 'Health: -';
app.Label2.Text = 'K: -';
app.Label3.Text = 'RUL: -';
app.Label4.Text = 'Sev: -';
app.TextArea.Value = {'Ready. Select asset and press Start.'};  % 1x1 cell
end


function onStart(app)
ud = app.UIFigure.UserData;

SLOW_PERIOD_SEC = 2.0;   % seconds per update (increase to slow further)

if ~ud.hasState
    assetIdx = round(app.Spinner.Value);
    ud.state = realtime_engine_init(ud.projectRoot, assetIdx, 10);  % 10 real days per model day
    ud.hasState = true;

    cla(app.UIAxes);  cla(app.UIAxes2);  cla(app.UIAxes3);

    app.TextArea.Value = {sprintf('Running asset #%d ...', assetIdx)};
end

% Create or update timer
if isempty(ud.tmr) || ~isvalid(ud.tmr)
    ud.tmr = timer( ...
        'ExecutionMode','fixedRate', ...
        'Period', SLOW_PERIOD_SEC, ...
        'TimerFcn', @(~,~) onTick(app));
else
    ud.tmr.Period = SLOW_PERIOD_SEC;
end

app.UIFigure.UserData = ud;

if strcmp(ud.tmr.Running,'off')
    start(ud.tmr);
end
end


function onPause(app)
ud = app.UIFigure.UserData;
if ~isempty(ud.tmr) && isvalid(ud.tmr) && strcmp(ud.tmr.Running,'on')
    stop(ud.tmr);
end
app.TextArea.Value = {'Paused.'};
end


function onStop(app)
ud = app.UIFigure.UserData;

if ~isempty(ud.tmr) && isvalid(ud.tmr)
    stop(ud.tmr);
    delete(ud.tmr);
end

ud.tmr      = [];
ud.hasState = false;
ud.state    = [];
app.UIFigure.UserData = ud;

cla(app.UIAxes);  cla(app.UIAxes2);  cla(app.UIAxes3);

app.Label.Text  = 'Health: -';
app.Label2.Text = 'K: -';
app.Label3.Text = 'RUL: -';
app.Label4.Text = 'Sev: -';

app.TextArea.Value = {'Stopped. Press Start to run again.'};
end


function onAssetChanged(app)
onStop(app);
app.TextArea.Value = {sprintf('Asset set to #%d. Press Start.', round(app.Spinner.Value))};
end


function onTick(app)
ud = app.UIFigure.UserData;
if ~ud.hasState || isempty(ud.state)
    return;
end

[ud.state, ~] = realtime_engine_step(ud.state);  % out not used from engine
app.UIFigure.UserData = ud;

% We infer the "current index" from how many non-NaN health values we have
idx = find(~isnan(ud.state.Health),1,'last');
if isempty(idx)
    idx = 1;
end

t = ud.state.tReal(1:idx);
RULtrue = ud.state.RULtrue_real(1:idx);
RULpred = ud.state.RUL_pred_real(1:idx);
Health  = ud.state.Health(1:idx);
Kidx    = ud.state.K_index(1:idx);
Sev     = ud.state.sev_log(1:idx);

RUL_START_DAYS = 100;
currentTime    = t(end);

% Check if we have any valid model predictions yet
validMaskAll = ~isnan(RULpred);
hasPred      = any(validMaskAll);

% ---- Finished? (approximate when true RUL ~ 0) ----
if RULtrue(end) <= 0
    totalDays   = t(end);
    finalHealth = Health(end);
    finalK      = Kidx(end);
    finalSev    = Sev(end);

    summary = {
        sprintf('Run completed.')
        sprintf('Total lifetime: %.1f real days (%.2f years)', totalDays, totalDays/365)
        sprintf('Final Health: %.1f %%', finalHealth)
        sprintf('Final K index: %.1f', finalK)
        sprintf('Final Severity: %.3f', finalSev)
        };

    app.TextArea.Value = summary;

    onStop(app);   % keeps plots, clears timer
    return;
end

% ---- KPI labels ----
app.Label.Text  = sprintf('Health: %.1f %%', Health(end));
app.Label2.Text = sprintf('K: %.1f', Kidx(end));
app.Label4.Text = sprintf('Sev: %.3f', Sev(end));

% Display RUL value for label & text area
if hasPred
    lastRUL = RULpred(find(validMaskAll,1,'last'));
else
    % Fallback to true RUL until we have real predictions
    lastRUL = RULtrue(end);
end

if currentTime < RUL_START_DAYS
    app.Label3.Text = sprintf('RUL: after %.0f days', RUL_START_DAYS);
else
    app.Label3.Text = sprintf('RUL: %.1f days', lastRUL);
end

% ---- TextArea: RUL + alerts ----
lines = {};

if currentTime < RUL_START_DAYS
    lines{end+1,1} = sprintf('RUL: will be shown after %.0f days', RUL_START_DAYS);
else
    if hasPred
        lines{end+1,1} = sprintf('Current predicted RUL: %.1f days', lastRUL);
    else
        lines{end+1,1} = sprintf('RUL (fallback, true curve): %.1f days', lastRUL);
    end
end

% Simple alert rules
if Health(end) < 60
    lines{end+1,1} = 'Alert: Health < 60%';
end
if lastRUL < 100
    lines{end+1,1} = 'Alert: RUL < 100 days';
end
if numel(lines) == 1
    lines{end+1,1} = 'No other active alerts.';
end

app.TextArea.Value = lines;

% ---- Plots ----

% Health & K
ax = app.UIAxes; cla(ax);
yyaxis(ax,'left');
plot(ax, t, Kidx, 'b-', 'LineWidth', 2);
ylabel(ax,'K index');
yyaxis(ax,'right');
plot(ax, t, Health, 'g--', 'LineWidth', 2);
ylabel(ax,'Health (%)');
xlabel(ax,'Real days');
title(ax,'Health & K'); grid(ax,'on');

% RUL – only show from RUL_START_DAYS
ax = app.UIAxes2; cla(ax);
maskTime = t >= RUL_START_DAYS;
if any(maskTime)
    if hasPred
        % use model prediction (smoothed via movmean)
        RULplot = smoothdata(RULpred, 'movmean', 5);
        plot(ax, t(maskTime), RULplot(maskTime), 'r-', 'LineWidth', 2);
        legend(ax, 'Predicted RUL','Location','best');
    else
        % fallback to true RUL
        plot(ax, t(maskTime), RULtrue(maskTime), 'c--', 'LineWidth', 2);
        legend(ax, 'True RUL (fallback)','Location','best');
    end
end
xlabel(ax,'Real days');
ylabel(ax,'RUL (days)');
title(ax,sprintf('RUL (shown from %.0f days)', RUL_START_DAYS));
grid(ax,'on');

% Severity
ax = app.UIAxes3; cla(ax);
plot(ax, t, Sev, 'm-', 'LineWidth', 2);
xlabel(ax,'Real days');
ylabel(ax,'Severity');
title(ax,'Severity'); grid(ax,'on');
end