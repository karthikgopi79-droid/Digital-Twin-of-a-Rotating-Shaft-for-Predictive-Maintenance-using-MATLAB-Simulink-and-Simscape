function train_degradation_lstm_model()
%TRAIN_DEGRADATION_LSTM_MODEL
%  Train LSTM-based RUL predictor on synthetic degradation sequences.
%
%  Uses:
%    - data/sequences/degradation_lstm_data.mat  (from create_synthetic_degradation_sequences)
%
%  Saves:
%    - data/models/degradation_lstm.mat with variable 'degradationNet'

    % --- Locate project root and load data ---
    scriptPath = mfilename('fullpath');
    [scriptDir, ~, ~] = fileparts(scriptPath);
    projectRoot = fileparts(fileparts(scriptDir));

    dataFile = fullfile(projectRoot, 'data', 'sequences', 'degradation_lstm_data.mat');
    if ~isfile(dataFile)
        error('Degradation LSTM data not found: %s. Run create_synthetic_degradation_sequences first.', dataFile);
    end

    S = load(dataFile, 'XSeq', 'YSeq', 'winLenDays');
    XSeq = S.XSeq;
    YSeq = S.YSeq;
    seqLen = S.winLenDays;

    numSamples  = numel(XSeq);
    numFeatures = size(XSeq{1}, 1);

    fprintf('Loaded %d sequences (features=%d, seqLen=%d)\n', numSamples, numFeatures, seqLen);

    % --- Split into train / test (time-independent) ---
    rng(0);
    idx = randperm(numSamples);
    nTrain = round(0.7 * numSamples);

    XTrain = XSeq(idx(1:nTrain));
    YTrain = YSeq(idx(1:nTrain));
    XTest  = XSeq(idx(nTrain+1:end));
    YTest  = YSeq(idx(nTrain+1:end));

    % Further validation split from train (20% of train)
    nVal = round(0.2 * nTrain);
    XVal = XTrain(1:nVal);
    YVal = YTrain(1:nVal);
    XTrainSub = XTrain(nVal+1:end);
    YTrainSub = YTrain(nVal+1:end);

    % --- Define LSTM architecture (close to your spec) ---
    layers = [
        sequenceInputLayer(numFeatures, 'Name','input')

        lstmLayer(100, 'OutputMode','sequence', 'Name','lstm1')
        dropoutLayer(0.2, 'Name','drop1')

        lstmLayer(50, 'OutputMode','last', 'Name','lstm2')
        dropoutLayer(0.2, 'Name','drop2')

        fullyConnectedLayer(32, 'Name','fc1')
        reluLayer('Name','relu1')

        fullyConnectedLayer(1, 'Name','fc_out')
        regressionLayer('Name','regressionoutput')
    ];

    % --- Training options (close to your spec) ---
    options = trainingOptions('adam', ...
        'InitialLearnRate', 1e-3, ...
        'MaxEpochs', 200, ...
        'MiniBatchSize', 32, ...
        'Shuffle', 'every-epoch', ...
        'ValidationData', {XVal, YVal}, ...
        'ValidationFrequency', 50, ...
        'ValidationPatience', 15, ...
        'GradientThreshold', 1, ...
        'Plots', 'training-progress', ...
        'Verbose', false);

    % --- Train ---
    fprintf('Training LSTM degradation/RUL model...\n');
    degradationNet = trainNetwork(XTrainSub, YTrainSub, layers, options);

    % --- Evaluate ---
    YPredTest = predict(degradationNet, XTest, 'MiniBatchSize', 32);

    rmse = sqrt(mean((YPredTest - YTest).^2));
    mae  = mean(abs(YPredTest - YTest));
    R2   = 1 - sum((YPredTest - YTest).^2) / sum((YTest - mean(YTest)).^2);

    within10 = mean(abs(YPredTest - YTest) <= 10) * 100;
    within20 = mean(abs(YPredTest - YTest) <= 20) * 100;

    fprintf('\nTest performance on synthetic sequences:\n');
    fprintf('  RMSE = %.2f days\n', rmse);
    fprintf('  MAE  = %.2f days\n', mae);
    fprintf('  R^2  = %.3f\n', R2);
    fprintf('  %% within ±10 days: %.1f %%\n', within10);
    fprintf('  %% within ±20 days: %.1f %%\n', within20);

    % --- Save model ---
    outDir = fullfile(projectRoot, 'data', 'models');
    if ~isfolder(outDir)
        mkdir(outDir);
    end

    outFile = fullfile(outDir, 'degradation_lstm.mat');
    save(outFile, 'degradationNet');

    fprintf('\nSaved degradation LSTM model to %s\n', outFile);

    % --- Optional: visualize some example sequences ---
    % pick a few random test samples
    nPlot = min(5, numel(XTest));
    idxPlot = randperm(numel(XTest), nPlot);
    figure; tiledlayout(nPlot,1);
    for i = 1:nPlot
        k = idxPlot(i);
        Xk = XTest{k};
        trueRUL = YTest(k);
        predRUL = YPredTest(k);

        nexttile;
        plot(1:seqLen, Xk(1,:));  % first feature over 30 days
        yyaxis right;
        stem(seqLen, trueRUL, 'g', 'LineWidth',1.5); hold on;
        stem(seqLen, predRUL, 'r--', 'LineWidth',1.5);
        ylabel('RUL (days)');
        title(sprintf('Seq %d: true RUL=%.1f, pred=%.1f', k, trueRUL, predRUL));
        legend('feat1','true RUL','pred RUL');
    end
end